// ===== Theme Toggle (Dark/Light Mode) =====
(function() {
  const logos = {
    dark: '/wp-content/themes/KuLaDig/assets/images/KuLaDig_W_img.png',
    light: '/wp-content/themes/KuLaDig/assets/images/KuLaDig_B_img.png'
  };
  
  function getPreferredTheme() {
    const stored = localStorage.getItem('theme');
    if (stored) return stored;
    return window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
  }
  
  function setTheme(theme) {
    document.body.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
    
    const themeIcons = document.querySelectorAll('.theme-icon');
    themeIcons.forEach(icon => {
      icon.textContent = theme === 'light' ? '🌙' : '☀️';
    });
    
    const brandLogo = document.getElementById('brandLogo');
    if (brandLogo) {
      brandLogo.src = theme === 'dark' ? logos.dark : logos.light;
    }
  }
  
  document.addEventListener('DOMContentLoaded', function() {
    setTheme(getPreferredTheme());
    
    const themeToggle = document.getElementById('themeToggle');
    themeToggle?.addEventListener('click', () => {
      const currentTheme = document.body.getAttribute('data-theme') || 'dark';
      const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
      setTheme(newTheme);
    });
  });
})();

// ===== Modal Handler =====
(function() {
  document.addEventListener('click', (e) => {
    const trigger = e.target.closest('[data-open-modal]');
    if (!trigger) return;
    
    e.preventDefault();
    const modalId = trigger.getAttribute('data-open-modal');
    const modal = document.getElementById(modalId);
    
    if (modal) {
      modal.classList.add('is-open');
      modal.setAttribute('aria-hidden', 'false');
      document.body.style.overflow = 'hidden';
      
      const firstInput = modal.querySelector('input');
      if (firstInput) {
        setTimeout(() => firstInput.focus(), 100);
      }
    }
  });
  
  document.addEventListener('click', (e) => {
    const closeBtn = e.target.closest('[data-close-modal]');
    if (!closeBtn) return;
    
    const modal = closeBtn.closest('.modal');
    if (modal) {
      modal.classList.remove('is-open');
      modal.setAttribute('aria-hidden', 'true');
      document.body.style.overflow = '';
    }
  });
  
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      const openModal = document.querySelector('.modal.is-open');
      if (openModal) {
        openModal.classList.remove('is-open');
        openModal.setAttribute('aria-hidden', 'true');
        document.body.style.overflow = '';
      }
    }
  });
})();

// ===== Login Handler =====
function handleLogin(e) {
  e.preventDefault();
  
  const email = document.getElementById('loginEmail')?.value;
  const password = document.getElementById('loginPassword')?.value;
  
  console.log('Login-Versuch:', { email, password });
  
  alert('Login-Funktion ist noch nicht implementiert. Dies ist nur eine Demo!');
  
  const modal = document.getElementById('loginModal');
  if (modal) {
    modal.classList.remove('is-open');
    document.body.style.overflow = '';
  }
  
  return false;
}

// ===== Mobile Menu (Burger) - FIXED =====
const burger = document.querySelector('.burger');
const drawer = document.getElementById('drawer');

let drawerInitialized = false;

burger?.addEventListener('click', () => {
  const open = burger.getAttribute('aria-expanded') === 'true';
  burger.setAttribute('aria-expanded', String(!open));
  drawer.classList.toggle('mobile-hidden');
  
  if(!open){
    // Nur beim ersten Öffnen Inhalt erstellen
    if (!drawerInitialized) {
      drawer.classList.add('mobile-drawer');
      drawer.innerHTML = `
        <nav aria-label="Mobiles Menü">
          <a href="${KLD?.objektBase?.replace('/objekt/', '/karte/') || '/karte/'}">Karte entdecken</a>
          <a href="/objekte">Objekte</a>
          <a href="/routen">Routen</a>
          <a href="/mitmachen">Ort einreichen</a>
          <a href="#" data-open-modal="loginModal">Anmelden</a>
          <button id="mobileThemeToggle" style="margin: 12px 20px; padding: 10px; border: 1px solid #1d2530; background: rgba(255,255,255,0.06); border-radius: 8px; width: calc(100% - 40px); cursor: pointer; color: #f5f7fb;">
            <span id="mobileThemeIcon">🌙</span> Theme wechseln
          </button>
          <a href="/karte" class="cta-mini" style="display:inline-block;margin:12px 20px">Jetzt entdecken</a>
        </nav>
      `;
      
      const mobileToggle = document.getElementById('mobileThemeToggle');
      const mobileIcon = document.getElementById('mobileThemeIcon');
      const currentTheme = document.body.getAttribute('data-theme') || 'dark';
      mobileIcon.textContent = currentTheme === 'light' ? '🌙' : '☀️';
      
      mobileToggle?.addEventListener('click', () => {
        const theme = document.body.getAttribute('data-theme') || 'dark';
        const newTheme = theme === 'dark' ? 'light' : 'dark';
        document.body.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        mobileIcon.textContent = newTheme === 'light' ? '🌙' : '☀️';
        
        const desktopIcon = document.querySelector('.theme-toggle .theme-icon');
        if (desktopIcon) {
          desktopIcon.textContent = newTheme === 'light' ? '🌙' : '☀️';
        }
        
        const brandLogo = document.getElementById('brandLogo');
        if (brandLogo) {
          const logos = {
            dark: '/wp-content/themes/kuladig/assets/images/KuLaDig_B_img.png',
            light: '/wp-content/themes/kuladig/assets/images/KuLaDig_W_img.png'
          };
          brandLogo.src = newTheme === 'dark' ? logos.dark : logos.light;
        }
      });
      
      drawerInitialized = true;
    }
  }
});

// ===== Smooth Scrolling =====
document.addEventListener('click', (e) => {
  const a = e.target.closest('a[href^="#"]');
  if(!a) return;
  const id = a.getAttribute('href');
  if(id.length > 1){
    e.preventDefault();
    const target = document.querySelector(id);
    if (target) {
      target.scrollIntoView({behavior:'smooth', block: 'start'});
    }
  }
});

// ===== Hero Buttons =====
document.getElementById('openMap')?.addEventListener('click', () => {
  const karte = document.getElementById('karte');
  if (karte) {
    karte.scrollIntoView({behavior:'smooth'});
  } else {
    window.location.href = KLD?.objektBase?.replace('/objekt/', '/karte/') || '/karte/';
  }
});

document.getElementById('discover')?.addEventListener('click', () => {
  const objekte = document.getElementById('objekte');
  if (objekte) {
    objekte.scrollIntoView({behavior:'smooth'});
  } else {
    window.location.href = '/objekte/';
  }
});

// ===== Geo-HTTPS/Chrome-Flag Hinweis (nur Landing Page) =====
(function () {
  'use strict';

  const STORAGE_KEY = 'kld_geo_flag_hint_dismissed_v1';

  function isLocalhost(hostname) {
    return hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '::1';
  }

  function shouldShowHint() {
    // Nur wenn nicht in einem HTTPS sind
    if (window.isSecureContext) return false;
    if (isLocalhost(window.location.hostname)) return false;
    return true;
  }

  function openModal(modal) {
    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }

  function closeModal(modal) {
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  document.addEventListener('DOMContentLoaded', () => {
    // Nur Landing Page
    const isHome = document.body.classList.contains('home') || document.body.classList.contains('front-page');
    if (!isHome) return;

    if (!shouldShowHint()) return;
    if (localStorage.getItem(STORAGE_KEY) === '1') return;

    const modal = document.getElementById('geoHelpModal');
    if (!modal) return;

    // Origin in Modal einsetzen
    modal.querySelectorAll('[data-geo-origin]').forEach(el => {
      el.textContent = window.location.origin;
    });

    const geoHint = document.getElementById('geo-hint');
    if (geoHint) geoHint.textContent = '';

    openModal(modal);
  });

  // Buttons im Modal
  document.addEventListener('click', async (e) => {
    const dismiss = e.target.closest('[data-geo-dismiss]');
    if (dismiss) {
      localStorage.setItem(STORAGE_KEY, '1');
      const modal = dismiss.closest('.modal');
      if (modal) closeModal(modal);
      return;
    }

    const copyBtn = e.target.closest('[data-geo-copy]');
    if (copyBtn) {
      const origin = window.location.origin;
      try {
        await navigator.clipboard.writeText(origin);
        copyBtn.textContent = 'Kopiert ✓';
        setTimeout(() => (copyBtn.textContent = 'Origin kopieren'), 1200);
      } catch (err) {
        // Fallback: prompt
        window.prompt('Origin kopieren:', origin);
      }
    }
  });
})();

// ===== Rechtliches Page JavaScript =====
(function() {
    'use strict';

    if (!document.querySelector('.rechtliches-wrapper')) {
        return;
    }

    function initSmoothScrolling() {
        const navLinks = document.querySelectorAll('.rechtliches-nav a');
        
        navLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href').substring(1);
                const targetSection = document.getElementById(targetId);
                
                if (targetSection) {
                    targetSection.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                    
                    history.pushState(null, null, '#' + targetId);
                    updateActiveNavLink(this);
                }
            });
        });
    }

    function updateActiveNavLink(activeLink) {
        const navLinks = document.querySelectorAll('.rechtliches-nav a');
        navLinks.forEach(link => link.classList.remove('active'));
        if (activeLink) {
            activeLink.classList.add('active');
        }
    }

    function initIntersectionObserver() {
        const sections = document.querySelectorAll('.rechtliches-section');
        
        const observerOptions = {
            root: null,
            rootMargin: '-100px 0px -66%',
            threshold: 0
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const sectionId = entry.target.getAttribute('id');
                    const correspondingLink = document.querySelector(`.rechtliches-nav a[href="#${sectionId}"]`);
                    
                    if (correspondingLink) {
                        updateActiveNavLink(correspondingLink);
                        
                        if (history.replaceState) {
                            history.replaceState(null, null, '#' + sectionId);
                        }
                    }
                }
            });
        }, observerOptions);
        
        sections.forEach(section => observer.observe(section));
    }

    function initBackToTopButton() {
        const backToTopBtn = document.querySelector('.back-to-top');
        
        if (!backToTopBtn) return;
        
        window.addEventListener('scroll', () => {
            if (window.pageYOffset > 300) {
                backToTopBtn.classList.add('visible');
            } else {
                backToTopBtn.classList.remove('visible');
            }
        });
        
        backToTopBtn.addEventListener('click', (e) => {
            e.preventDefault();
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
            
            history.pushState('', document.title, window.location.pathname + window.location.search);
        });
    }

    function scrollToHashOnLoad() {
        setTimeout(() => {
            const hash = window.location.hash;
            if (hash) {
                const targetSection = document.querySelector(hash);
                const correspondingLink = document.querySelector(`.rechtliches-nav a[href="${hash}"]`);
                
                if (targetSection) {
                    targetSection.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
                
                if (correspondingLink) {
                    updateActiveNavLink(correspondingLink);
                }
            } else {
                const firstLink = document.querySelector('.rechtliches-nav a');
                if (firstLink) {
                    updateActiveNavLink(firstLink);
                }
            }
        }, 100);
    }

    function handlePopState() {
        window.addEventListener('popstate', () => {
            const hash = window.location.hash;
            if (hash) {
                const targetSection = document.querySelector(hash);
                const correspondingLink = document.querySelector(`.rechtliches-nav a[href="${hash}"]`);
                
                if (targetSection) {
                    targetSection.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
                
                if (correspondingLink) {
                    updateActiveNavLink(correspondingLink);
                }
            }
        });
    }

    function init() {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', init);
            return;
        }
        
        initSmoothScrolling();
        initIntersectionObserver();
        initBackToTopButton();
        scrollToHashOnLoad();
        handlePopState();
    }

    init();

})();

// ===== Live-Suche mit KuLaDig API =====
(function() {
  'use strict';

  const searchInput = document.getElementById('q');
  const suggestList = document.getElementById('suggest');
  
  if (!searchInput || !suggestList) return;

  let searchTimeout;
  let currentRequest = null;

  searchInput.addEventListener('input', function(e) {
    const query = e.target.value.trim();
    
    if (query.length < 2) {
      hideSuggestions();
      return;
    }

    clearTimeout(searchTimeout);
    
    searchTimeout = setTimeout(() => {
      performSearch(query);
    }, 300);
  });

  searchInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
      e.preventDefault();
      const query = searchInput.value.trim();
      if (query) {
        window.location.href = '/objekte/?suchText=' + encodeURIComponent(query);
      }
    }
  });

  document.addEventListener('click', function(e) {
    if (!e.target.closest('.search') && !e.target.closest('#suggest') && !e.target.closest('.suggest-list')) {
      hideSuggestions();
    }
  });

  async function performSearch(query) {
    try {
      if (currentRequest) {
        currentRequest.abort();
      }

      showLoading();

      const controller = new AbortController();
      currentRequest = controller;

      const url = `https://www.kuladig.de/api/public/Objekt?suchText=${encodeURIComponent(query)}&ObjektTyp=KuladigObjekt&Seite=0`;
      
      const response = await fetch(url, {
        signal: controller.signal,
        headers: {
          'Accept': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error('API Fehler');
      }

      const data = await response.json();
      
      const results = sortByRelevance(data.Ergebnis || [], query);
      
      displaySuggestions(results.slice(0, 12), query);

    } catch (error) {
      if (error.name === 'AbortError') {
        return;
      }
      console.error('Suchfehler:', error);
      showError();
    } finally {
      currentRequest = null;
    }
  }

  function sortByRelevance(results, query) {
    const queryLower = query.toLowerCase();
    
    return results.sort((a, b) => {
      const nameA = (a.Name || '').toLowerCase();
      const nameB = (b.Name || '').toLowerCase();
      const descA = (a.Beschreibung || '').toLowerCase();
      const descB = (b.Beschreibung || '').toLowerCase();

      let scoreA = 0;
      let scoreB = 0;

      if (nameA === queryLower) scoreA += 1000;
      if (nameB === queryLower) scoreB += 1000;

      if (nameA.startsWith(queryLower)) scoreA += 500;
      if (nameB.startsWith(queryLower)) scoreB += 500;

      if (nameA.includes(queryLower)) scoreA += 100;
      if (nameB.includes(queryLower)) scoreB += 100;

      if (descA.includes(queryLower)) scoreA += 10;
      if (descB.includes(queryLower)) scoreB += 10;

      return scoreB - scoreA;
    });
  }

  function displaySuggestions(results, query) {
    if (!results || results.length === 0) {
      showNoResults();
      return;
    }

    const html = results.map(item => {
      const name = escapeHtml(item.Name || 'Ohne Titel');
      const desc = escapeHtml(item.Beschreibung || '');
      const shortDesc = desc.length > 80 ? desc.slice(0, 80) + '...' : desc;
      const id = item.Id || '';
      const url = id ? `/objekt/?id=${encodeURIComponent(id)}` : '#';
      
      const highlightedName = highlightMatch(name, query);

      return `
        <a href="${url}" class="suggest-item" role="option">
          <div class="suggest-icon">📍</div>
          <div class="suggest-content">
            <div class="suggest-title">${highlightedName}</div>
            ${shortDesc ? `<div class="suggest-desc">${shortDesc}</div>` : ''}
          </div>
        </a>
      `;
    }).join('');

    suggestList.innerHTML = html;
    showSuggestions();
  }
    function setHidden(card, hidden){
      card.classList.toggle('kld-hidden', !!hidden);
    }
    
  function highlightMatch(text, query) {
    const regex = new RegExp(`(${escapeRegex(query)})`, 'gi');
    return text.replace(regex, '<mark>$1</mark>');
  }

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  function escapeRegex(text) {
    return text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  function showLoading() {
    suggestList.innerHTML = `
      <div class="suggest-loading">
        <div class="suggest-spinner"></div>
        <span>Suche läuft...</span>
      </div>
    `;
    showSuggestions();
  }

  function showNoResults() {
    suggestList.innerHTML = `
      <div class="suggest-empty">
        <span>Keine Ergebnisse gefunden</span>
      </div>
    `;
    showSuggestions();
  }

  function showError() {
    suggestList.innerHTML = `
      <div class="suggest-error">
        <span>⚠️ Fehler bei der Suche</span>
      </div>
    `;
    showSuggestions();
  }

  function showSuggestions() {
    selectedIndex = -1;
    suggestList.classList.add('is-visible');
    searchInput.setAttribute('aria-expanded', 'true');
  }

  function hideSuggestions() {
    suggestList.classList.remove('is-visible');
    searchInput.setAttribute('aria-expanded', 'false');
    suggestList.innerHTML = '';
  }

  let selectedIndex = -1;

searchInput.addEventListener('keydown', function(e) {
  const items = suggestList.querySelectorAll('.suggest-item');

  if (e.key === 'ArrowDown') {
    if (!items.length) return;
    e.preventDefault();
    selectedIndex = Math.min(selectedIndex + 1, items.length - 1);
    updateSelection(items);

  } else if (e.key === 'ArrowUp') {
    if (!items.length) return;
    e.preventDefault();
    selectedIndex = Math.max(selectedIndex - 1, -1);
    updateSelection(items);

  } else if (e.key === 'Enter') {
    // 1) Wenn Suggest ausgewählt: klick den ausgewählten Eintrag
    if (items.length && selectedIndex >= 0) {
      e.preventDefault();
      items[selectedIndex].click();
      return;
    }

    // 2) Sonst normale Suche -> zur Objekte-Seite mit suchText
    const q = (searchInput.value || '').trim();
    if (!q) return;

    e.preventDefault();
    window.location.href = KLD.objektBase.replace(/\/objekt\/?$/, '/objekte/') + '?suchText=' + encodeURIComponent(q);

  } else if (e.key === 'Escape') {
    hideSuggestions();
  }
});


  function updateSelection(items) {
    items.forEach((item, index) => {
      if (index === selectedIndex) {
        item.classList.add('is-selected');
        item.scrollIntoView({ block: 'nearest' });
      } else {
        item.classList.remove('is-selected');
      }
    });
  }

})();